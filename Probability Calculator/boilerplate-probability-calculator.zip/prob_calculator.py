import copy
import random
# Consider using the modules imported above.

class Hat:


def experiment(hat, expected_balls, num_balls_drawn, num_experiments):
